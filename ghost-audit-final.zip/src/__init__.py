"""Deletion Detective AI package."""
